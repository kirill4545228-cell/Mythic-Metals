@echo off
REM Gradle wrapper bootstrap script (Windows).
REM Run `gradle wrapper` once to generate gradle-wrapper.jar, then gradlew works normally.
set APP_HOME=%~dp0
java -classpath "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
