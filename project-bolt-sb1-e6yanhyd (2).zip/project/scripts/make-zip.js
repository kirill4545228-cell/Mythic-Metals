/*
 * Creates mythic-metals-addon-src.zip — the entire project ready to upload to GitHub.
 * Uses only Node's built-in zlib module (no dependencies).
 * Run: node scripts/make-zip.js
 */
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const ROOT = path.join(__dirname, '..');
const OUT = path.join(ROOT, 'mythic-metals-addon-src.zip');

// --- Minimal ZIP writer (no external deps) -------------------------------
// Implements STORE (no compression) for maximum compatibility + deflate for text files.
// CRC32 table
const crcTable = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    t[n] = c >>> 0;
  }
  return t;
})();

function crc32(buf) {
  let c = ~0;
  for (let i = 0; i < buf.length; i++) c = crcTable[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
  return ~c >>> 0;
}

class ZipWriter {
  constructor() {
    this.chunks = [];
    this.central = [];
    this.offset = 0;
  }
  _u16(v) { const b = Buffer.alloc(2); b.writeUInt16LE(v, 0); return b; }
  _u32(v) { const b = Buffer.alloc(4); b.writeUInt32LE(v, 0); return b; }

  addFile(name, data) {
    const nameBuf = Buffer.from(name, 'utf8');
    const crc = crc32(data);
    // Use deflate for text, store for binary > save ratio
    let compressed, method;
    const isText = /\.(json|java|gradle|properties|md|yml|txt|js|gitignore|toml|mcmeta)$/.test(name)
      || name.endsWith('.gitignore');
    if (isText && data.length > 64) {
      compressed = zlib.deflateRawSync(data, { level: 9 });
      method = 8;
    } else {
      compressed = data;
      method = 0;
    }

    const local = Buffer.concat([
      this._u32(0x04034b50),  // local file header sig
      this._u16(20),          // version needed
      this._u16(0),           // flags
      this._u16(method),     // compression method
      this._u16(0), this._u16(0), // mod time, mod date
      this._u32(crc),
      this._u32(compressed.length),
      this._u32(data.length),
      this._u16(nameBuf.length),
      this._u16(0),           // extra field length
      nameBuf,
      compressed,
    ]);

    this.chunks.push(local);
    const localOffset = this.offset;
    this.offset += local.length;

    this.central.push(Buffer.concat([
      this._u32(0x02014b50),  // central dir sig
      this._u16(20),          // version made by
      this._u16(20),          // version needed
      this._u16(0),           // flags
      this._u16(method),     // compression
      this._u16(0), this._u16(0),
      this._u32(crc),
      this._u32(compressed.length),
      this._u32(data.length),
      this._u16(nameBuf.length),
      this._u16(0),           // extra
      this._u16(0),           // comment
      this._u16(0),           // disk number
      this._u16(0),           // internal attrs
      this._u32(0),            // external attrs
      this._u32(localOffset),
      nameBuf,
    ]));
  }

  buffer() {
    const cdStart = this.offset;
    let cdSize = 0;
    for (const c of this.central) cdSize += c.length;
    const allChunks = [...this.chunks, ...this.central];
    const eocd = Buffer.concat([
      this._u32(0x06054b50),  // EOCD sig
      this._u16(0), this._u16(0),
      this._u16(this.central.length),
      this._u16(this.central.length),
      this._u32(cdSize),
      this._u32(cdStart),
      this._u16(0),           // comment length
    ]);
    allChunks.push(eocd);
    return Buffer.concat(allChunks);
  }
}

// --- Collect files --------------------------------------------------------
const EXCLUDE_DIRS = new Set([
  '.git', 'node_modules', 'build', '.gradle', 'out', 'dist', 'run', '.bolt',
]);
const EXCLUDE_FILES = new Set([
  'mythic-metals-addon-src.zip', 'package-lock.json', 'index.js', 'package.json',
]);
const EXCLUDE_PREFIXES = ['.github/']; // workflow is inside the zip already

function shouldExclude(relPath) {
  const parts = relPath.split('/');
  for (const p of parts) if (EXCLUDE_DIRS.has(p)) return true;
  if (EXCLUDE_FILES.has(parts[parts.length - 1])) return true;
  for (const pre of EXCLUDE_PREFIXES) if (relPath.startsWith(pre)) return true;
  return false;
}

const zip = new ZipWriter();
let count = 0;

function walk(dir, prefix = '') {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const e of entries) {
    const full = path.join(dir, e.name);
    const rel = prefix ? `${prefix}/${e.name}` : e.name;
    if (shouldExclude(rel)) continue;
    if (e.isDirectory()) {
      walk(full, rel);
    } else {
      const data = fs.readFileSync(full);
      zip.addFile(rel, data);
      count++;
      console.log('added', rel);
    }
  }
}

walk(ROOT);
fs.writeFileSync(OUT, zip.buffer());
console.log(`\nDone! ${count} files -> ${OUT} (${fs.statSync(OUT).size} bytes)`);
