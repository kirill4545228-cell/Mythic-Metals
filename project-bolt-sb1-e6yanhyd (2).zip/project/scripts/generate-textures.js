/*
 * Texture generator for Mythic Metals Addon.
 * Produces 16x16 (and one 64x64) PNG files using only Node's built-in zlib module.
 * Run: node scripts/generate-textures.js
 */
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const ASSETS = path.join(__dirname, '..', 'src', 'main', 'resources', 'assets', 'mythic_metals_addon');

// --- Minimal PNG encoder -------------------------------------------------
function crc32(buf) {
  let c = ~0;
  for (let i = 0; i < buf.length; i++) {
    c ^= buf[i];
    for (let k = 0; k < 8; k++) c = (c >>> 1) ^ (0xEDB88320 & -(c & 1));
  }
  return ~c >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, 'ascii');
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0);
  return Buffer.concat([len, typeBuf, data, crc]);
}

/**
 * pixels: Uint8Array of length w*h*4 (RGBA)
 */
function encodePng(w, h, pixels) {
  const sig = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // color type RGBA
  ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;

  // Filtered scanlines: prepend filter byte 0 (None) per row
  const stride = w * 4;
  const raw = Buffer.alloc((stride + 1) * h);
  for (let y = 0; y < h; y++) {
    raw[y * (stride + 1)] = 0;
    for (let x = 0; x < stride; x++) {
      raw[y * (stride + 1) + 1 + x] = pixels[y * stride + x];
    }
  }
  const idat = zlib.deflateSync(raw);
  return Buffer.concat([sig, chunk('IHDR', ihdr), chunk('IDAT', idat), chunk('IEND', Buffer.alloc(0))]);
}

// --- Color helpers --------------------------------------------------------
function rgba(r, g, b, a = 255) { return [r, g, b, a]; }
function mix(c1, c2, t) {
  return [
    Math.round(c1[0] * (1 - t) + c2[0] * t),
    Math.round(c1[1] * (1 - t) + c2[1] * t),
    Math.round(c1[2] * (1 - t) + c2[2] * t),
    Math.round(c1[3] * (1 - t) + c2[3] * t),
  ];
}

// Mythril palette - a blue-green mythical metal
const M = {
  mythril:      [78, 196, 196],
  mythrilDark:  [40, 130, 140],
  mythrilLight: [150, 226, 226],
  mythrilGlow:  [200, 250, 250],
  stone:        [128, 128, 138],
  stoneDark:    [90, 90, 100],
  deepslate:    [70, 70, 80],
  deepslateDark:[50, 50, 58],
  raw:          [110, 170, 168],
  rawDark:      [70, 120, 118],
  dust:         [140, 210, 208],
  essence:      [90, 230, 220],
  heart:        [80, 210, 200],
  heartCore:    [220, 250, 250],
  brown:        [120, 85, 55],
  brownDark:    [90, 65, 40],
  stick:        [150, 110, 70],
  stickDark:    [100, 70, 45],
  bg:           [0, 0, 0, 0], // transparent
};

// --- Texture builders -----------------------------------------------------
const W = 16, H = 16;
function blank() {
  const p = new Uint8Array(W * H * 4);
  return p;
}
function setPx(p, x, y, c) {
  if (x < 0 || x >= W || y < 0 || y >= H) return;
  const i = (y * W + x) * 4;
  p[i] = c[0]; p[i + 1] = c[1]; p[i + 2] = c[2]; p[i + 3] = c[3] ?? 255;
}
function fillRect(p, x0, y0, x1, y1, c) {
  for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) setPx(p, x, y, c);
}
function fillAll(p, c) { fillRect(p, 0, 0, W - 1, H - 1, c); }
// Simple seeded noise for texture
function seedRand(seed) {
  let s = seed >>> 0;
  return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 0xFFFFFFFF; };
}
function speckle(p, seed, base, variants) {
  const rnd = seedRand(seed);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const t = rnd();
    let c = base;
    if (t > 0.78) c = variants[0];
    else if (t > 0.5) c = variants[1];
    setPx(p, x, y, c);
  }
}

// --- Block textures -------------------------------------------------------
function blockMetal() {
  const p = blank();
  speckle(p, 42, M.mythril, [M.mythrilLight, M.mythrilDark]);
  // subtle border shading
  for (let i = 0; i < W; i++) {
    setPx(p, i, 0, mix(M.mythril, M.mythrilDark, 0.5));
    setPx(p, i, H - 1, mix(M.mythril, M.mythrilDark, 0.4));
    setPx(p, 0, i, mix(M.mythril, M.mythrilDark, 0.3));
    setPx(p, W - 1, i, mix(M.mythril, M.mythrilLight, 0.3));
  }
  return p;
}

function blockRaw() {
  const p = blank();
  speckle(p, 7, M.raw, [M.rawDark, M.mythrilLight]);
  for (let i = 0; i < W; i++) {
    setPx(p, i, 0, mix(M.raw, M.rawDark, 0.5));
    setPx(p, i, H - 1, mix(M.raw, M.rawDark, 0.4));
  }
  return p;
}

function ore(stoneColor, stoneDark, seed) {
  const p = blank();
  speckle(p, seed, stoneColor, [stoneDark, mix(stoneColor, stoneDark, 0.5)]);
  // ore clumps
  const clumps = [
    [3, 3, 5, 5], [9, 4, 11, 6], [4, 9, 6, 11], [10, 10, 12, 12], [7, 2, 8, 3],
  ];
  for (const [x0, y0, x1, y1] of clumps) {
    fillRect(p, x0, y0, x1, y1, M.mythril);
    setPx(p, x0, y0, M.mythrilLight);
    setPx(p, x1, y1, M.mythrilDark);
    setPx(p, x0, y1, M.mythrilDark);
    setPx(p, x1, y0, M.mythrilLight);
    setPx(p, (x0 + x1) >> 1, (y0 + y1) >> 1, M.mythrilGlow);
  }
  return p;
}

// --- Item textures --------------------------------------------------------
function ingot() {
  const p = blank();
  const base = M.mythril, dark = M.mythrilDark, light = M.mythrilLight;
  // ingot shape: horizontal bar
  for (let y = 4; y <= 11; y++) {
    for (let x = 2; x <= 13; x++) {
      let c = base;
      const top = y === 4, bottom = y === 11;
      const left = x === 2, right = x === 13;
      if (top) c = light;
      else if (bottom) c = dark;
      else if (left) c = mix(base, dark, 0.4);
      else if (right) c = mix(base, light, 0.4);
      setPx(p, x, y, c);
    }
  }
  // highlight
  for (let x = 4; x <= 11; x++) setPx(p, x, 5, M.mythrilGlow);
  setPx(p, 3, 5, mix(M.mythrilGlow, base, 0.5));
  return p;
}

function nugget() {
  const p = blank();
  const base = M.mythril, dark = M.mythrilDark, light = M.mythrilLight;
  // small pebble shape
  for (let y = 5; y <= 10; y++) {
    for (let x = 5; x <= 10; x++) {
      let c = base;
      const dx = x - 7, dy = y - 7;
      if (dx * dx + dy * dy <= 9) {
        if (y === 5) c = light;
        else if (y === 10) c = dark;
        setPx(p, x, y, c);
      }
    }
  }
  setPx(p, 7, 6, M.mythrilGlow);
  return p;
}

function rawOreItem() {
  const p = blank();
  const base = M.raw, dark = M.rawDark, light = M.mythrilLight;
  // irregular chunk
  const pts = [
    [4, 4], [11, 4], [12, 7], [11, 11], [5, 12], [3, 8],
  ];
  for (let y = 3; y <= 12; y++) {
    for (let x = 3; x <= 12; x++) {
      let c = base;
      if (y === 3 || y === 4) c = light;
      else if (y === 11 || y === 12) c = dark;
      setPx(p, x, y, c);
    }
  }
  // mythril specks
  setPx(p, 6, 6, M.mythrilGlow);
  setPx(p, 9, 8, M.mythrilLight);
  setPx(p, 5, 10, M.mythril);
  setPx(p, 10, 5, M.mythril);
  return p;
}

function dust() {
  const p = blank();
  const rnd = seedRand(99);
  for (let y = 4; y <= 11; y++) {
    for (let x = 3; x <= 12; x++) {
      if (rnd() > 0.35) {
        const c = mix(M.dust, M.mythrilLight, rnd());
        setPx(p, x, y, c);
      }
    }
  }
  return p;
}

function essence() {
  const p = blank();
  // glowing orb
  for (let y = 3; y <= 12; y++) {
    for (let x = 4; x <= 11; x++) {
      const dx = x - 7, dy = y - 7;
      const d = Math.sqrt(dx * dx + dy * dy);
      if (d <= 4.5) {
        const t = 1 - d / 4.5;
        const c = mix(M.mythril, M.essence, t);
        setPx(p, x, y, c);
        if (d < 1.5) setPx(p, x, y, M.mythrilGlow);
      }
    }
  }
  return p;
}

function heart() {
  const p = blank();
  // heart-of-the-sea style star
  for (let y = 2; y <= 13; y++) {
    for (let x = 2; x <= 13; x++) {
      const dx = x - 7, dy = y - 7;
      const d = Math.sqrt(dx * dx + dy * dy);
      if (d <= 5) {
        const t = 1 - d / 5;
        const c = mix(M.mythrilDark, M.heart, t);
        setPx(p, x, y, c);
      }
      if (d < 2) setPx(p, x, y, M.heartCore);
    }
  }
  // sparkle
  setPx(p, 5, 4, M.mythrilGlow);
  setPx(p, 9, 10, M.mythrilGlow);
  return p;
}

// --- Tool textures (mythril head + stick handle) -------------------------
function toolHeadBase(p, headTop, headBottom, headColor, headDark, headLight) {
  // default: fill nothing
}

function pickaxe() {
  const p = blank();
  const base = M.mythril, dark = M.mythrilDark, light = M.mythrilLight;
  // pick head: top arc
  for (let x = 2; x <= 13; x++) setPx(p, x, 3, x % 2 === 0 ? light : base);
  for (let x = 3; x <= 12; x++) setPx(p, x, 4, base);
  setPx(p, 2, 4, dark); setPx(p, 13, 4, dark);
  // handle
  for (let i = 5; i <= 13; i++) {
    setPx(p, 7, i, M.stick);
    setPx(p, 8, i, M.stickDark);
  }
  setPx(p, 7, 5, base); setPx(p, 8, 5, dark);
  return p;
}

function axe() {
  const p = blank();
  const base = M.mythril, dark = M.mythrilDark, light = M.mythrilLight;
  // axe head on left
  for (let y = 3; y <= 7; y++) {
    for (let x = 3; x <= 8; x++) {
      let c = base;
      if (x === 3) c = light;
      else if (x === 8) c = dark;
      if (y === 3 || y === 7) c = mix(c, dark, 0.4);
      setPx(p, x, y, c);
    }
  }
  setPx(p, 3, 3, M.mythrilGlow);
  // handle
  for (let i = 5; i <= 13; i++) {
    setPx(p, 9, i, M.stick);
    setPx(p, 10, i, M.stickDark);
  }
  return p;
}

function shovel() {
  const p = blank();
  const base = M.mythril, dark = M.mythrilDark, light = M.mythrilLight;
  // shovel head (square scoop)
  for (let y = 3; y <= 7; y++) {
    for (let x = 6; x <= 9; x++) {
      let c = base;
      if (y === 3) c = light;
      else if (y === 7) c = dark;
      setPx(p, x, y, c);
    }
  }
  setPx(p, 6, 3, M.mythrilGlow);
  // handle
  for (let i = 6; i <= 13; i++) {
    setPx(p, 7, i, M.stick);
    setPx(p, 8, i, M.stickDark);
  }
  return p;
}

function sword() {
  const p = blank();
  const base = M.mythril, dark = M.mythrilDark, light = M.mythrilLight;
  // blade (diagonal)
  for (let i = 2; i <= 11; i++) {
    setPx(p, 11 - i, i, base);
    setPx(p, 12 - i, i, light);
    setPx(p, 10 - i, i, dark);
  }
  // guard
  for (let x = 4; x <= 8; x++) setPx(p, x, 11, M.stickDark);
  setPx(p, 6, 11, base);
  // handle
  for (let i = 12; i <= 14; i++) {
    setPx(p, 5, i, M.stick);
    setPx(p, 6, i, M.stickDark);
  }
  return p;
}

function hoe() {
  const p = blank();
  const base = M.mythril, dark = M.mythrilDark, light = M.mythrilLight;
  // hoe head (small top bar)
  for (let x = 8; x <= 12; x++) setPx(p, x, 3, base);
  setPx(p, 8, 3, light); setPx(p, 12, 3, dark);
  setPx(p, 10, 4, base);
  // handle
  for (let i = 4; i <= 13; i++) {
    setPx(p, 7, i, M.stick);
    setPx(p, 8, i, M.stickDark);
  }
  setPx(p, 8, 4, base);
  return p;
}

// --- Armor textures (simplified icons) ------------------------------------
function armorPiece(shape) {
  const p = blank();
  const base = M.mythril, dark = M.mythrilDark, light = M.mythrilLight;
  shape(p, base, dark, light);
  return p;
}

function helmetShape(p, base, dark, light) {
  // helmet: dome
  for (let x = 4; x <= 11; x++) setPx(p, x, 4, light);
  for (let x = 3; x <= 12; x++) setPx(p, x, 5, base);
  for (let x = 3; x <= 12; x++) setPx(p, x, 6, base);
  for (let x = 3; x <= 12; x++) setPx(p, x, 7, dark);
  // opening
  setPx(p, 6, 7, M.bg); setPx(p, 7, 7, M.bg); setPx(p, 8, 7, M.bg); setPx(p, 9, 7, M.bg);
  setPx(p, 4, 5, dark); setPx(p, 11, 5, dark);
}

function chestplateShape(p, base, dark, light) {
  // chestplate: torso
  for (let y = 4; y <= 11; y++) {
    for (let x = 4; x <= 11; x++) {
      let c = base;
      if (y === 4) c = light;
      else if (y === 11) c = dark;
      setPx(p, x, y, c);
    }
  }
  // arms
  for (let y = 5; y <= 8; y++) {
    setPx(p, 3, y, base); setPx(p, 12, y, base);
  }
  // split
  for (let y = 5; y <= 10; y++) setPx(p, 7, y, dark);
  setPx(p, 7, 4, M.mythrilGlow);
}

function leggingsShape(p, base, dark, light) {
  // leggings: two legs
  for (let y = 4; y <= 11; y++) {
    for (let x = 4; x <= 11; x++) {
      let c = base;
      if (y === 4) c = light;
      if (y >= 10) c = dark;
      setPx(p, x, y, c);
    }
  }
  // gap between legs
  for (let y = 8; y <= 11; y++) { setPx(p, 7, y, M.bg); setPx(p, 8, y, M.bg); }
  // belt
  for (let x = 3; x <= 12; x++) setPx(p, x, 4, dark);
  setPx(p, 3, 4, base); setPx(p, 12, 4, base);
}

function bootsShape(p, base, dark, light) {
  // boots
  for (let y = 6; y <= 11; y++) {
    for (let x = 4; x <= 11; x++) {
      let c = base;
      if (y === 6) c = light;
      else if (y === 11) c = dark;
      setPx(p, x, y, c);
    }
  }
  // top opening
  for (let x = 5; x <= 10; x++) setPx(p, x, 5, dark);
  setPx(p, 5, 5, M.bg); setPx(p, 10, 5, M.bg);
  setPx(p, 5, 11, M.bg); setPx(p, 6, 11, M.bg);
}

// --- Mod icon (64x64) -----------------------------------------------------
function modIcon() {
  const W2 = 64, H2 = 64;
  const p = new Uint8Array(W2 * H2 * 4);
  // background gradient dark teal
  for (let y = 0; y < H2; y++) {
    for (let x = 0; x < W2; x++) {
      const t = y / H2;
      const c = mix([22, 38, 48], [10, 22, 30], t);
      const i = (y * W2 + x) * 4;
      p[i] = c[0]; p[i + 1] = c[1]; p[i + 2] = c[2]; p[i + 3] = 255;
    }
  }
  // mythril ingot centered, scaled up
  const ix = 12, iy = 24, iw = 40, ih = 16;
  for (let y = 0; y < ih; y++) {
    for (let x = 0; x < iw; x++) {
      const px = ix + x, py = iy + y;
      let c = M.mythril;
      const top = y === 0, bottom = y === ih - 1;
      const left = x === 0, right = x === iw - 1;
      if (top) c = M.mythrilLight;
      else if (bottom) c = M.mythrilDark;
      else if (left) c = mix(M.mythril, M.mythrilDark, 0.4);
      else if (right) c = mix(M.mythril, M.mythrilLight, 0.4);
      const i = (py * W2 + px) * 4;
      p[i] = c[0]; p[i + 1] = c[1]; p[i + 2] = c[2]; p[i + 3] = 255;
    }
  }
  // glow highlight
  for (let x = 4; x < iw - 4; x++) {
    const i = (iy * W2 + (ix + x)) * 4;
    p[i] = M.mythrilGlow[0]; p[i + 1] = M.mythrilGlow[1]; p[i + 2] = M.mythrilGlow[2];
  }
  return { w: W2, h: H2, pixels: p };
}

// --- Write all textures ---------------------------------------------------
function writeTex(relPath, w, h, pixels) {
  const fullPath = path.join(ASSETS, relPath);
  fs.mkdirSync(path.dirname(fullPath), { recursive: true });
  fs.writeFileSync(fullPath, encodePng(w, h, pixels));
  console.log('wrote', relPath);
}

function write16(relPath, pixels) { writeTex(relPath, W, H, pixels); }

// Blocks
write16('textures/block/mythril_block.png', blockMetal());
write16('textures/block/raw_mythril_block.png', blockRaw());
write16('textures/block/mythril_ore.png', ore(M.stone, M.stoneDark, 11));
write16('textures/block/deepslate_mythril_ore.png', ore(M.deepslate, M.deepslateDark, 17));

// Items - materials
write16('textures/item/mythril_ingot.png', ingot());
write16('textures/item/mythril_nugget.png', nugget());
write16('textures/item/raw_mythril.png', rawOreItem());
write16('textures/item/mythril_dust.png', dust());
write16('textures/item/mythril_essence.png', essence());
write16('textures/item/mythril_heart.png', heart());

// Items - tools
write16('textures/item/mythril_pickaxe.png', pickaxe());
write16('textures/item/mythril_axe.png', axe());
write16('textures/item/mythril_shovel.png', shovel());
write16('textures/item/mythril_sword.png', sword());
write16('textures/item/mythril_hoe.png', hoe());

// Items - armor
write16('textures/item/mythril_helmet.png', armorPiece(helmetShape));
write16('textures/item/mythril_chestplate.png', armorPiece(chestplateShape));
write16('textures/item/mythril_leggings.png', armorPiece(leggingsShape));
write16('textures/item/mythril_boots.png', armorPiece(bootsShape));

// Mod icon
const icon = modIcon();
writeTex('icon.png', icon.w, icon.h, icon.pixels);

console.log('All textures generated.');
