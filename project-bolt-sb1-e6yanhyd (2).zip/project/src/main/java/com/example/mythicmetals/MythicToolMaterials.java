package com.example.mythicmetals;

import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;
import net.minecraft.util.Lazy;

/**
 * Mythril tier: slightly better than diamond. Sits between diamond and netherite.
 */
public enum MythicToolMaterials implements ToolMaterial {
    MYTHRIL(
            5,
            2031,
            9.0F,
            3.0F,
            15,
            new Lazy<>(() -> Ingredient.ofItems(MythicItems.MYTHRIL_INGOT))
    );

    private final int miningLevel;
    private final int itemDurability;
    private final float miningSpeed;
    private final float attackDamage;
    private final int enchantability;
    private final Lazy<Ingredient> repairIngredient;

    MythicToolMaterials(int miningLevel, int durability, float miningSpeed, float attackDamage, int enchantability, Lazy<Ingredient> repairIngredient) {
        this.miningLevel = miningLevel;
        this.itemDurability = durability;
        this.miningSpeed = miningSpeed;
        this.attackDamage = attackDamage;
        this.enchantability = enchantability;
        this.repairIngredient = repairIngredient;
    }

    @Override
    public int getDurability() {
        return this.itemDurability;
    }

    @Override
    public float getMiningSpeedMultiplier() {
        return this.miningSpeed;
    }

    @Override
    public float getAttackDamage() {
        return this.attackDamage;
    }

    @Override
    public int getMiningLevel() {
        return this.miningLevel;
    }

    @Override
    public int getEnchantability() {
        return this.enchantability;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return this.repairIngredient.get();
    }
}
