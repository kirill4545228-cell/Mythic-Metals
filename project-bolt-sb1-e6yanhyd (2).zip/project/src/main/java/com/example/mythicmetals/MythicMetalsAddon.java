package com.example.mythicmetals;

import com.example.mythicmetals.world.MythicOreGeneration;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class MythicMetalsAddon implements ModInitializer {
    public static final String MOD_ID = "mythic_metals_addon";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final ItemGroup MYTHIC_GROUP = FabricItemGroup.builder()
            .icon(() -> new ItemStack(MythicItems.MYTHRIL_INGOT))
            .displayName(Text.translatable("itemGroup.mythic_metals_addon"))
            .entries((displayContext, entries) -> {
                entries.add(MythicItems.MYTHRIL_RAW);
                entries.add(MythicItems.MYTHRIL_INGOT);
                entries.add(MythicItems.MYTHRIL_NUGGET);
                entries.add(MythicItems.MYTHRIL_PICKAXE);
                entries.add(MythicItems.MYTHRIL_AXE);
                entries.add(MythicItems.MYTHRIL_SHOVEL);
                entries.add(MythicItems.MYTHRIL_SWORD);
                entries.add(MythicItems.MYTHRIL_HOE);
                entries.add(MythicItems.MYTHRIL_HELMET);
                entries.add(MythicItems.MYTHRIL_CHESTPLATE);
                entries.add(MythicItems.MYTHRIL_LEGGINGS);
                entries.add(MythicItems.MYTHRIL_BOOTS);
                entries.add(MythicItems.MYTHRIL_DUST);
                entries.add(MythicBlocks.MYTHRIL_BLOCK.asItem());
                entries.add(MythicBlocks.MYTHRIL_ORE.asItem());
                entries.add(MythicBlocks.DEEPSLATE_MYTHRIL_ORE.asItem());
                entries.add(MythicBlocks.RAW_MYTHRIL_BLOCK.asItem());
                entries.add(MythicItems.MYTHRIL_HEART);
                entries.add(MythicItems.MYTHRIL_ESSENCE);
            })
            .build();

    @Override
    public void onInitialize() {
        MythicBlocks.register();
        MythicItems.register();
        MythicToolMaterials.MYTHRIL.toString();
        MythicArmorMaterials.MYTHRIL.toString();

        Identifier groupId = new Identifier(MOD_ID, "mythic_group");
        Registry.register(Registries.ITEM_GROUP, groupId, MYTHIC_GROUP);

        ItemGroupEvents.modifyEntriesEvent(ItemGroup.INGREDIENTS).register(entries -> {
            entries.add(MythicItems.MYTHRIL_INGOT);
            entries.add(MythicItems.MYTHRIL_NUGGET);
            entries.add(MythicItems.MYTHRIL_RAW);
            entries.add(MythicItems.MYTHRIL_DUST);
            entries.add(MythicItems.MYTHRIL_ESSENCE);
            entries.add(MythicItems.MYTHRIL_HEART);
        });

        MythicOreGeneration.register();

        LOGGER.info("Mythic Metals Addon initialized. The legend of mythril begins.");
    }

    public static Identifier id(String path) {
        return new Identifier(MOD_ID, path);
    }
}
