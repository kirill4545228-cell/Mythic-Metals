package com.example.mythicmetals;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.ExperienceDroppingBlock;
import net.minecraft.block.OreBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.math.intprovider.UniformIntProvider;

/**
 * All mythril-related blocks.
 */
public final class MythicBlocks {

    public static final Block MYTHRIL_BLOCK = new Block(AbstractBlock.Settings.copy(Blocks.IRON_BLOCK)
            .strength(6.0F, 6.0F)
            .requiresTool());

    public static final Block MYTHRIL_ORE = new OreBlock(AbstractBlock.Settings.copy(Blocks.DIAMOND_ORE)
            .strength(4.0F, 4.0F)
            .requiresTool(),
            UniformIntProvider.create(4, 9));

    public static final Block DEEPSLATE_MYTHRIL_ORE = new OreBlock(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_DIAMOND_ORE)
            .strength(5.0F, 5.0F)
            .requiresTool(),
            UniformIntProvider.create(4, 9));

    public static final Block RAW_MYTHRIL_BLOCK = new Block(AbstractBlock.Settings.copy(Blocks.RAW_IRON_BLOCK)
            .strength(4.0F, 4.0F)
            .requiresTool());

    private MythicBlocks() {
    }

    public static void register() {
        registerBlock("mythril_block", MYTHRIL_BLOCK);
        registerBlock("mythril_ore", MYTHRIL_ORE);
        registerBlock("deepslate_mythril_ore", DEEPSLATE_MYTHRIL_ORE);
        registerBlock("raw_mythril_block", RAW_MYTHRIL_BLOCK);
    }

    private static void registerBlock(String name, Block block) {
        Registry.register(Registries.BLOCK, MythicMetalsAddon.id(name), block);
        Registry.register(Registries.ITEM, MythicMetalsAddon.id(name),
                new BlockItem(block, new Item.Settings()));
    }
}
