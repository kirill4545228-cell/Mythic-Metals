package com.example.mythicmetals;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.Item;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Rarity;

/**
 * All mythril-related items.
 */
public final class MythicItems {

    public static final Item MYTHRIL_RAW = new Item(new Item.Settings());
    public static final Item MYTHRIL_INGOT = new Item(new Item.Settings().rarity(Rarity.UNCOMMON));
    public static final Item MYTHRIL_NUGGET = new Item(new Item.Settings());
    public static final Item MYTHRIL_DUST = new Item(new Item.Settings());
    public static final Item MYTHRIL_ESSENCE = new Item(new Item.Settings().rarity(Rarity.RARE));
    public static final Item MYTHRIL_HEART = new Item(new Item.Settings().rarity(Rarity.EPIC).fireproof());

    public static final ToolItem MYTHRIL_PICKAXE = new PickaxeItem(MythicToolMaterials.MYTHRIL, 2, -2.8F, new Item.Settings());
    public static final ToolItem MYTHRIL_AXE = new AxeItem(MythicToolMaterials.MYTHRIL, 8.0F, -3.0F, new Item.Settings());
    public static final ToolItem MYTHRIL_SHOVEL = new ShovelItem(MythicToolMaterials.MYTHRIL, 2.5F, -3.0F, new Item.Settings());
    public static final ToolItem MYTHRIL_SWORD = new SwordItem(MythicToolMaterials.MYTHRIL, 4, -2.4F, new Item.Settings());
    public static final ToolItem MYTHRIL_HOE = new HoeItem(MythicToolMaterials.MYTHRIL, -1, -1.0F, new Item.Settings());

    public static final ArmorItem MYTHRIL_HELMET = new ArmorItem(MythicArmorMaterials.MYTHRIL, EquipmentSlot.HEAD, new Item.Settings());
    public static final ArmorItem MYTHRIL_CHESTPLATE = new ArmorItem(MythicArmorMaterials.MYTHRIL, EquipmentSlot.CHEST, new Item.Settings());
    public static final ArmorItem MYTHRIL_LEGGINGS = new ArmorItem(MythicArmorMaterials.MYTHRIL, EquipmentSlot.LEGS, new Item.Settings());
    public static final ArmorItem MYTHRIL_BOOTS = new ArmorItem(MythicArmorMaterials.MYTHRIL, EquipmentSlot.FEET, new Item.Settings());

    private MythicItems() {
    }

    public static void register() {
        register("raw_mythril", MYTHRIL_RAW);
        register("mythril_ingot", MYTHRIL_INGOT);
        register("mythril_nugget", MYTHRIL_NUGGET);
        register("mythril_dust", MYTHRIL_DUST);
        register("mythril_essence", MYTHRIL_ESSENCE);
        register("mythril_heart", MYTHRIL_HEART);

        register("mythril_pickaxe", MYTHRIL_PICKAXE);
        register("mythril_axe", MYTHRIL_AXE);
        register("mythril_shovel", MYTHRIL_SHOVEL);
        register("mythril_sword", MYTHRIL_SWORD);
        register("mythril_hoe", MYTHRIL_HOE);

        register("mythril_helmet", MYTHRIL_HELMET);
        register("mythril_chestplate", MYTHRIL_CHESTPLATE);
        register("mythril_leggings", MYTHRIL_LEGGINGS);
        register("mythril_boots", MYTHRIL_BOOTS);
    }

    private static void register(String name, Item item) {
        Registry.register(Registries.ITEM, MythicMetalsAddon.id(name), item);
    }
}
