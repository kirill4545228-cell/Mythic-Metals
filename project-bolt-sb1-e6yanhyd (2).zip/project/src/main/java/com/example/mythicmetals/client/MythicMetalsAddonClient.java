package com.example.mythicmetals.client;

import com.example.mythicmetals.MythicMetalsAddon;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.minecraft.client.render.RenderLayer;

public final class MythicMetalsAddonClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        MythicMetalsAddon.LOGGER.info("Mythic Metals Addon client init.");
        BlockRenderLayerMap.INSTANCE.putBlock(
                net.minecraft.block.Blocks.DIAMOND_BLOCK, RenderLayer.getCutout());
    }
}
