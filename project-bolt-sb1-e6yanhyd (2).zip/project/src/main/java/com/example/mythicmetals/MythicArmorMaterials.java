package com.example.mythicmetals;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.recipe.Ingredient;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Lazy;

import java.util.EnumMap;
import java.util.function.Supplier;

/**
 * Mythril armor: protection value between diamond and netherite.
 */
public enum MythicArmorMaterials implements ArmorMaterial {
    MYTHRIL("mythril", 38, makeProtectionMap(4, 7, 9, 4), 12,
            SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 3.0F, 0.1F,
            new Lazy<>(() -> Ingredient.ofItems(MythicItems.MYTHRIL_INGOT)));

    private static final EnumMap<EquipmentSlot, Integer> makeProtectionMap(int boots, int leggings, int chest, int helmet) {
        EnumMap<EquipmentSlot, Integer> map = new EnumMap<>(EquipmentSlot.class);
        map.put(EquipmentSlot.BOOTS, boots);
        map.put(EquipmentSlot.LEGGINGS, leggings);
        map.put(EquipmentSlot.CHEST, chest);
        map.put(EquipmentSlot.HEAD, helmet);
        return map;
    }

    private static final int[] BASE_DURABILITY = new int[]{13, 15, 16, 11};

    private final String name;
    private final int durabilityMultiplier;
    private final EnumMap<EquipmentSlot, Integer> protectionAmounts;
    private final int enchantability;
    private final SoundEvent equipSound;
    private final float toughness;
    private final float knockbackResistance;
    private final Lazy<Ingredient> repairIngredient;

    MythicArmorMaterials(String name, int durability, EnumMap<EquipmentSlot, Integer> protection, int enchantability,
                         SoundEvent equipSound, float toughness, float knockbackResistance, Lazy<Ingredient> repairIngredient) {
        this.name = name;
        this.durabilityMultiplier = durability;
        this.protectionAmounts = protection;
        this.enchantability = enchantability;
        this.equipSound = equipSound;
        this.toughness = toughness;
        this.knockbackResistance = knockbackResistance;
        this.repairIngredient = repairIngredient;
    }

    @Override
    public int getDurability(EquipmentSlot slot) {
        return BASE_DURABILITY[slot.getEntitySlotId()] * this.durabilityMultiplier;
    }

    @Override
    public int getProtectionAmount(EquipmentSlot slot) {
        return this.protectionAmounts.get(slot);
    }

    @Override
    public int getEnchantability() {
        return this.enchantability;
    }

    @Override
    public SoundEvent getEquipSound() {
        return this.equipSound;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return this.repairIngredient.get();
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public float getToughness() {
        return this.toughness;
    }

    @Override
    public float getKnockbackResistance() {
        return this.knockbackResistance;
    }
}
