# Mythic Metals Addon

A Fabric mod for **Minecraft 1.20.1** that adds the legendary metal **Mythril** — a rare,
blue-green metal found deep underground, stronger than diamond and with high enchantability.

## Features

- **Mythril Ore** — spawns in the Overworld between Y -64 and 60, rarer than diamond.
- **Deepslate Mythril Ore** — found even deeper, below Y -10.
- **Raw Mythril** — drops from ore (affected by Fortune), smelt into ingots.
- **Mythril Ingot, Nugget, Block** — standard metal processing chain.
- **Raw Mythril Block** — storage block for raw mythril.
- **Mythril Dust, Essence, Heart** — decorative/lore ingredients for future expansions.
- **Mythril Tools** — pickaxe, axe, shovel, sword, hoe (mining level 5, durability 2031).
- **Mythril Armor** — helmet, chestplate, leggings, boots (toughness 3.0, knockback resistance 0.1).
- **Custom Creative Tab** — all mod items grouped together under "Mythic Metals".

## Tool & Armor Stats

| Property | Value | Compared to |
|----------|-------|-------------|
| Mining Level | 5 | Netherite is 4 |
| Durability (tools) | 2031 uses | Netherite is 2031 |
| Mining Speed | 9.0 | Diamond is 8.0 |
| Attack Damage | 3.0 (base) | Diamond is 3.0 |
| Enchantability | 15 | Diamond is 10 |
| Armor Durability Multiplier | 38 | Diamond is 33 |
| Armor Toughness | 3.0 | Diamond is 2.0 |
| Knockback Resistance | 0.1 | Netherite is 0.1 |

## Build on GitHub (automatic — no JDK needed locally)

This repo includes a GitHub Actions workflow (`.github/workflows/build.yml`) that builds the mod
automatically on every push or manual trigger. You don't need Java installed on your computer.

### How to build & download

1. Push this project to a GitHub repository.
2. Go to the **Actions** tab in your repo on GitHub.
3. The "Build Mod" workflow runs automatically on every push. You can also trigger it manually:
   - Click **Build Mod** in the left sidebar → **Run workflow**.
4. When the build finishes, open that run and scroll down to **Artifacts**.
5. Download either:
   - **`mythic-metals-addon-jar`** — just the mod JAR (drop it in your `mods/` folder).
   - **`mythic-metals-addon-full`** — the entire project as a ZIP, including the built JAR.

The ZIP contains everything: source code, resources, textures, and the compiled mod inside
`build/libs/`.

## Building locally

If you prefer to build on your own machine, you need **JDK 17**.

### First-time setup (generating the Gradle wrapper)

The project ships without the `gradle-wrapper.jar` binary. Generate it once:

```bash
# Option A: if you have a system Gradle 8.x installed
gradle wrapper --gradle-version 8.7

# Option B: copy gradle-wrapper.jar from the official Fabric Example Mod
# https://github.com/FabricMC/fabric-example-mod
# Copy gradle/wrapper/gradle-wrapper.jar into this project's gradle/wrapper/ folder
```

### Build the mod

```bash
./gradlew build
```

The compiled mod JAR will be in `build/libs/mythic-metals-addon-1.0.0.jar`.

### Run in a dev environment

```bash
./gradlew runClient
```

## Installing

1. Install **Fabric Loader** 0.15+ for Minecraft 1.20.1.
2. Install **Fabric API** (required dependency).
3. Place the built JAR in your `.minecraft/mods/` folder.

## Project Structure

```
├── build.gradle                          # Fabric Loom build config
├── settings.gradle
├── gradle.properties                      # Versions (MC, Yarn, Loader, Fabric API)
├── gradle/wrapper/gradle-wrapper.properties
├── scripts/generate-textures.js          # Node script that generates all PNG textures
└── src/main/
    ├── java/com/example/mythicmetals/
    │   ├── MythicMetalsAddon.java         # Mod entrypoint + creative tab
    │   ├── MythicBlocks.java              # Block registry
    │   ├── MythicItems.java              # Item registry
    │   ├── MythicToolMaterials.java       # Tool material definition
    │   ├── MythicArmorMaterials.java      # Armor material definition
    │   ├── client/MythicMetalsAddonClient.java
    │   └── world/MythicOreGeneration.java # Ore biome injection
    └── resources/
        ├── fabric.mod.json
        ├── assets/mythic_metals_addon/    # Textures, models, blockstates, lang
        └── data/mythic_metals_addon/      # Recipes, loot tables, worldgen
```

## Regenerating Textures

All textures are generated procedurally by a Node.js script (no external dependencies):

```bash
node scripts/generate-textures.js
```

Edit the palette and drawing functions in `scripts/generate-textures.js` to customize the look.

## License

MIT
