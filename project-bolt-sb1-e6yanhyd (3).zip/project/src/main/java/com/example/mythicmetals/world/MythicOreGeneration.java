package com.example.mythicmetals.world;

import com.example.mythicmetals.MythicMetalsAddon;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.util.Identifier;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.feature.ConfiguredFeature;
import net.minecraft.world.gen.feature.PlacedFeature;

/**
 * Registers configured & placed features for mythril ore and injects them into biomes.
 * Mythril is rare: a few ores per chunk, buried deep (Y -20 to -64) in the Overworld.
 */
public final class MythicOreGeneration {

    public static final RegistryKey<ConfiguredFeature<?, ?>> ORE_MYTHRIL_OVERWORLD = RegistryKey.of(
            RegistryKeys.CONFIGURED_FEATURE,
            new Identifier(MythicMetalsAddon.MOD_ID, "ore_mythril_overworld"));
    public static final RegistryKey<ConfiguredFeature<?, ?>> ORE_MYTHRIL_DEEPSLATE = RegistryKey.of(
            RegistryKeys.CONFIGURED_FEATURE,
            new Identifier(MythicMetalsAddon.MOD_ID, "ore_mythril_deepslate"));

    public static final RegistryKey<PlacedFeature> PLACED_ORE_MYTHRIL_OVERWORLD = RegistryKey.of(
            RegistryKeys.PLACED_FEATURE,
            new Identifier(MythicMetalsAddon.MOD_ID, "ore_mythril_overworld_placed"));
    public static final RegistryKey<PlacedFeature> PLACED_ORE_MYTHRIL_DEEPSLATE = RegistryKey.of(
            RegistryKeys.PLACED_FEATURE,
            new Identifier(MythicMetalsAddon.MOD_ID, "ore_mythril_deepslate_placed"));

    private MythicOreGeneration() {
    }

    public static void register() {
        // Configured features are registered via JSON under data/<mod>/worldgen/configured_feature/
        // Placed features are registered via JSON under data/<mod>/worldgen/placed_feature/
        // (1.20.1 supports datapack-driven feature registration; Fabric auto-discovers them.)

        BiomeModifications.addFeature(
                BiomeSelectors.tag(BiomeTags.IS_OVERWORLD),
                GenerationStep.Feature.UNDERGROUND_ORES,
                PLACED_ORE_MYTHRIL_OVERWORLD
        );
        BiomeModifications.addFeature(
                BiomeSelectors.tag(BiomeTags.IS_OVERWORLD),
                GenerationStep.Feature.UNDERGROUND_ORES,
                PLACED_ORE_MYTHRIL_DEEPSLATE
        );
    }
}
